AmCharts.translations[ "export" ][ "hu" ] = {
	"fallback.save.text": "CTRL + C az adatok vágólapra történő másolásához.",
	"fallback.save.image": "Jobb egérgomb -> Save picture as... a kép mentéséhez.",

	"capturing.delayed.menu.label": "{{duration}}",
	"capturing.delayed.menu.title": "Kattints a megszakításhoz",

	"menu.label.print": "Nyomtatás",
	"menu.label.undo": "Visszavon",
	"menu.label.redo": "Mégis",
	"menu.label.cancel": "Mégse",

	"menu.label.save.image": "Kép mentése ...",
	"menu.label.save.data": "Mentés másként ...",

	"menu.label.draw": "Jegyzet ...",
	"menu.label.draw.change": "Módosítás ...",
	"menu.label.draw.add": "Hozzáadás ...",
	"menu.label.draw.shapes": "Alakzat ...",
	"menu.label.draw.colors": "Szín ...",
	"menu.label.draw.widths": "Méret ...",
	"menu.label.draw.opacities": "Átlátszóság ...",
	"menu.label.draw.text": "Szöveg",

	"menu.label.draw.modes": "Mód ...",
	"menu.label.draw.modes.pencil": "Toll",
	"menu.label.draw.modes.line": "Vonal",
	"menu.label.draw.modes.arrow": "Nyíl",

	"label.saved.from": "Mentve innen: "
}